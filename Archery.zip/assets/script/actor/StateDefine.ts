/**
 * 角色状态
 */
export enum StateDefine {

    Idle = "idle",

    Attack = "attack",

    Hit = "hit",

    Run = "run",

    Die = "die"
}